package com.carrental.entity;

public class HostVehicle {
	private int hostVehicleID;
    private int hostID;
    private int vehicleID;
    
    public HostVehicle() {}
    
	public HostVehicle(int hostVehicleID, int hostID, int vehicleID) {
		this.hostVehicleID = hostVehicleID;
		this.hostID = hostID;
		this.vehicleID = vehicleID;
	}
	public int getHostVehicleID() {
		return hostVehicleID;
	}
	public void setHostVehicleID(int hostVehicleID) {
		this.hostVehicleID = hostVehicleID;
	}
	public int getHostID() {
		return hostID;
	}
	public void setHostID(int hostID) {
		this.hostID = hostID;
	}
	public int getVehicleID() {
		return vehicleID;
	}
	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}
	
}
