package com.carrental.entity;

public class VehicleCity {
	private int vehicleCityID;
    private int vehicleID;
    private int cityID;
    
    public VehicleCity() {}
    
	public VehicleCity(int vehicleCityID, int vehicleID, int cityID) {
		super();
		this.vehicleCityID = vehicleCityID;
		this.vehicleID = vehicleID;
		this.cityID = cityID;
	}

	public int getVehicleCityID() {
		return vehicleCityID;
	}

	public void setVehicleCityID(int vehicleCityID) {
		this.vehicleCityID = vehicleCityID;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public int getCityID() {
		return cityID;
	}

	public void setCityID(int cityID) {
		this.cityID = cityID;
	}
}
