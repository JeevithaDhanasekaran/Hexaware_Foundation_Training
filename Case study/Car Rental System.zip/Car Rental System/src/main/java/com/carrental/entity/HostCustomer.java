package com.carrental.entity;

public class HostCustomer {
	private int hostID;
    private int customerID;
    
    public HostCustomer() {}
    
	public HostCustomer(int hostID, int customerID) {
		this.hostID = hostID;
		this.customerID = customerID;
	}
	public int getHostID() {
		return hostID;
	}
	public void setHostID(int hostID) {
		this.hostID = hostID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
    
    
    
}
