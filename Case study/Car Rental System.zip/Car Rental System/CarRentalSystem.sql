CREATE DATABASE IF NOT EXISTS CarRentalDB;
use carrentaldb;
-- drop database carrentaldb;
CREATE TABLE IF NOT EXISTS Customer (
    customerID INT AUTO_INCREMENT,
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    PRIMARY KEY (customerID)
);

CREATE TABLE IF NOT EXISTS ContactInfo (
    contactID INT AUTO_INCREMENT,
    customerID INT UNIQUE,
    email VARCHAR(100) UNIQUE,
    phoneNumber VARCHAR(15) UNIQUE,
    PRIMARY KEY (contactID),
    FOREIGN KEY (customerID) REFERENCES Customer(customerID),
    INDEX idx_email (email),
    INDEX idx_phone (phoneNumber) -- Improves search speed for email/phone lookups when customers log in
);
ALTER TABLE ContactInfo MODIFY COLUMN email VARCHAR(100) UNIQUE, 
ADD CONSTRAINT check_email CHECK (REGEXP_LIKE(email, '^[a-z0-9.]+@[a-z]+\.[a-z]{3,}$'));


CREATE TABLE IF NOT EXISTS Vehicle (
    vehicleID INT AUTO_INCREMENT,
    make VARCHAR(50),
    model VARCHAR(50),
    manufacturingYear INT,
    dailyRate DECIMAL(10,2),
    passengerCapacity INT,
    engineCapacity DECIMAL(10,2),
    PRIMARY KEY (vehicleID),
    INDEX idx_make_model (make, model) -- Helps in searching/filtering cars by make & model quickly
);

CREATE TABLE IF NOT EXISTS CarStatus (
    statusID INT AUTO_INCREMENT,
    status ENUM('available', 'notAvailable'),
    vehicleID INT UNIQUE,
    PRIMARY KEY (statusID),
    FOREIGN KEY (vehicleID) REFERENCES Vehicle(vehicleID)
);
ALTER TABLE CarStatus 
MODIFY COLUMN status ENUM('available', 'notAvailable') DEFAULT 'notAvailable';


CREATE TABLE IF NOT EXISTS Lease (
    leaseID INT AUTO_INCREMENT,
    vehicleID INT,
    customerID INT,
    startDate DATE,
    endDate DATE,
    leaseType ENUM('Daily', 'Monthly'),
    PRIMARY KEY (leaseID),
    FOREIGN KEY (vehicleID) REFERENCES Vehicle(vehicleID),
    INDEX idx_start_date (startDate) -- Makes date-based queries (past leases, active rentals) faster
);

CREATE TABLE IF NOT EXISTS Payment (
    paymentID INT AUTO_INCREMENT,
    leaseID INT UNIQUE,
    paymentDate DATE,
    amount DECIMAL(10,2),
    PRIMARY KEY (paymentID),
    FOREIGN KEY (leaseID) REFERENCES Lease(leaseID),
    INDEX idx_payment_date (paymentDate) -- Helps in retrieving payment history sorted by date efficiently.
);


CREATE TABLE IF NOT EXISTS HostCustomer (
    hostID INT AUTO_INCREMENT,
    customerID INT UNIQUE,
    hostingCityID INT NOT NULL,-- added this column ensure in DAO layer also 
    PRIMARY KEY (hostID),
    FOREIGN KEY (customerID) REFERENCES Customer(customerID)
);-- a customer can be both a renter and a host

CREATE TABLE IF NOT EXISTS HostVehicle (
    hostVehicleID INT AUTO_INCREMENT,
    hostID INT,
    vehicleID INT UNIQUE,
    PRIMARY KEY (hostVehicleID),
    FOREIGN KEY (hostID) REFERENCES HostCustomer(hostID),
    FOREIGN KEY (vehicleID) REFERENCES Vehicle(vehicleID)
);

CREATE TABLE IF NOT EXISTS City (
    cityID INT AUTO_INCREMENT,
    cityName VARCHAR(100) UNIQUE,
    PRIMARY KEY (cityID),
    INDEX idx_city_name (cityName) -- speed up city searches
); -- A City can have many Vehicles

CREATE TABLE IF NOT EXISTS VehicleCity (
    vehicleCityID INT AUTO_INCREMENT,
    vehicleID INT UNIQUE,
    cityID INT,
    PRIMARY KEY (vehicleCityID),
    FOREIGN KEY (vehicleID) REFERENCES Vehicle(vehicleID),
    FOREIGN KEY (cityID) REFERENCES City(cityID),
    INDEX idx_vehicle_city (vehicleID, cityID) -- optimizes vehicle queries by city
); -- a car belongs to only one city at a time

INSERT INTO City (cityName) VALUES 
('New York'),
('Los Angeles'),
('Chicago'),
('Houston'),
('San Francisco');

INSERT INTO Customer (firstName, lastName) VALUES 
('John', 'Doe'),
('Alice', 'Smith'),
('Michael', 'Johnson'),
('Emma', 'Brown'),
('David', 'Wilson');

INSERT INTO ContactInfo (customerID, email, phoneNumber) VALUES 
(1, 'john.doe@email.com', '1234567890'),
(2, 'alice.smith@email.com', '2345678901'),
(3, 'michael.johnson@email.com', '3456789012'),
(4, 'emma.brown@email.com', '4567890123'),
(5, 'david.wilson@email.com', '5678901234');

INSERT INTO Vehicle (make, model, manufacturingYear, dailyRate, passengerCapacity, engineCapacity) VALUES 
('Toyota', 'Corolla', 2022, 50.00, 5, 1.8),
('Honda', 'Civic', 2023, 55.00, 5, 2.0),
('Ford', 'Focus', 2021, 45.00, 5, 1.6),
('Chevrolet', 'Malibu', 2020, 40.00, 5, 1.5),
('Tesla', 'Model 3', 2023, 100.00, 5, 0.0), -- Electric Car
('BMW', 'X5', 2023, 90.00, 7, 3.0),
('Mercedes', 'C-Class', 2023, 85.00, 5, 2.5);

INSERT INTO HostCustomer (customerID, hostingCityID) VALUES 
(1, 1),  -- John Doe hosts in New York
(2, 2),  -- Alice Smith hosts in Los Angeles
(3, 3);  -- Michael Johnson hosts in Chicago



INSERT INTO CarStatus (status, vehicleID) VALUES 
('available', 1),
('notAvailable', 2),
('available', 3),
('available', 4),
('notAvailable', 5),
('available', 6),
('notAvailable', 7);

INSERT INTO HostVehicle (hostID, vehicleID) VALUES 
(1, 1), -- John Doe hosts Toyota Corolla
(1, 2), -- John Doe also hosts Honda Civic
(2, 3), -- Alice Smith hosts Ford Focus
(2, 4), -- Alice Smith also hosts Chevrolet Malibu
(3, 5), -- Michael Johnson hosts Tesla Model 3
(3, 6); -- Michael Johnson also hosts BMW X5

INSERT INTO VehicleCity (vehicleID, cityID) VALUES 
(1, 1), -- Toyota Corolla in New York
(2, 1), -- Honda Civic in New York
(3, 2), -- Ford Focus in Los Angeles
(4, 2), -- Chevrolet Malibu in Los Angeles
(5, 3), -- Tesla Model 3 in Chicago
(6, 3), -- BMW X5 in Chicago
(7, 4); -- Mercedes C-Class in Houston

INSERT INTO Lease (vehicleID, customerID, startDate, endDate, leaseType) VALUES 
(1, 4, '2024-03-01', '2024-03-07', 'Daily'),
(2, 5, '2024-03-05', '2024-03-12', 'Daily'),
(3, 1, '2024-02-20', '2024-03-20', 'Monthly'),
(4, 2, '2024-02-15', '2024-02-25', 'Daily'),
(5, 3, '2024-03-01', '2024-04-01', 'Monthly');

INSERT INTO Payment (leaseID, paymentDate, amount) VALUES 
(1, '2024-03-07', 350.00),
(2, '2024-03-12', 385.00),
(3, '2024-03-20', 1350.00),
(4, '2024-02-25', 400.00),
(5, '2024-04-01', 3000.00);

-- Find the total revenue generated from all leases
SELECT SUM(amount) AS total_revenue FROM Payment;

-- Find the average daily rental price of all vehicles
SELECT AVG(dailyRate) AS avg_daily_rate FROM Vehicle;

-- Find all active leases as of today
SELECT * FROM Lease WHERE '2024-02-20' BETWEEN startDate AND endDate;
select * from lease;

-- Find the number of days a customer has rented a car
SELECT leaseID, DATEDIFF(endDate, startDate) AS total_days FROM Lease;

-- Retrieve customers whose email contains 'gmail'
SELECT * FROM ContactInfo WHERE email LIKE '%email%';

-- Convert all vehicle makes to uppercase
SELECT UPPER(make) AS UpperCaseMake FROM Vehicle;

-- Find customers who have rented a vehicle in a specific city (e.g., 'New York')
set @city='New York';
SELECT * FROM Customer 
WHERE customerID IN (
    SELECT DISTINCT lease.customerID 
    FROM Lease lease
    JOIN VehicleCity vc ON lease.vehicleID = vc.vehicleID
    JOIN City c ON vc.cityID = c.cityID
    WHERE c.cityName = 'New York'
);

-- Find vehicles that have never been leased
SELECT * FROM Vehicle v
WHERE NOT EXISTS (
    SELECT 1 FROM Lease l WHERE l.vehicleID = v.vehicleID
);

-- Find customers who have rented more than one vehicle
SELECT c.customerID, c.firstName, c.lastName 
FROM Customer c
WHERE (
    SELECT COUNT(*) FROM Lease l WHERE l.customerID = c.customerID
) > 1;
SELECT * FROM lease;

-- retrieve all available vehicles for rent in a specific city
DELIMITER $$
CREATE PROCEDURE GetAvailableVehiclesByCity(IN cityNameParam VARCHAR(100))
BEGIN
    SELECT 
		v.vehicleID, 
        v.make, 
        v.model, 
        v.manufacturingYear, 
        v.dailyRate, 
        v.passengerCapacity, 
        v.engineCapacity
    FROM Vehicle v
    JOIN CarStatus cs ON v.vehicleID = cs.vehicleID
    JOIN VehicleCity vc ON v.vehicleID = vc.vehicleID
    JOIN City c ON vc.cityID = c.cityID
    WHERE cs.status = 'available' AND c.cityName = cityNameParam;
END $$
DELIMITER ;
CALL GetAvailableVehiclesByCity('Los Angeles');

-- Find all customers and their total amount spent on rentals
WITH CustomerPayments AS (
    SELECT l.customerID, SUM(p.amount) AS total_spent
    FROM Lease l
    JOIN Payment p ON l.leaseID = p.leaseID
    GROUP BY l.customerID
)
SELECT c.customerID, c.firstName, c.lastName, cp.total_spent
FROM Customer c
JOIN CustomerPayments cp ON c.customerID = cp.customerID;

-- Rank customers based on their total spending
SELECT 
	c.customerID, 
	c.firstName, 
    c.lastName, 
    SUM(p.amount) AS total_spent,
	RANK() OVER (ORDER BY SUM(p.amount) DESC) AS spending_rank
FROM Customer c
JOIN Lease l ON c.customerID = l.customerID
JOIN Payment p ON l.leaseID = p.leaseID
GROUP BY c.customerID;




