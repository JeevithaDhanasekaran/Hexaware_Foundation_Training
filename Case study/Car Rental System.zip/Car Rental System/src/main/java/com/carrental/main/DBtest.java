package com.carrental.main;

import java.sql.Connection;

import com.carrental.util.DBconnection;

public class DBtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn= DBconnection.getConnection();
		if(conn !=null) {
			System.out.println("Database connection test successful!");
		}
		else {
			System.out.println("Database connection failed");
		}
	}

}
