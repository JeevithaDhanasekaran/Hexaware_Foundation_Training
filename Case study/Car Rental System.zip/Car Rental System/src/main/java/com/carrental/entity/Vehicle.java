package com.carrental.entity;

public class Vehicle {
	private int vehicleID;
    private String make;
    private String model;
    private int manufacturingYear;
    private double dailyRate;
    private int passengerCapacity;
    private double engineCapacity;
    
    public Vehicle() {}
    
	public Vehicle(int vehicleID, String make, String model, int manufacturingYear, double dailyRate,
			int passengerCapacity, double engineCapacity) {
		this.vehicleID = vehicleID;
		this.make = make;
		this.model = model;
		this.manufacturingYear = manufacturingYear;
		this.dailyRate = dailyRate;
		this.passengerCapacity = passengerCapacity;
		this.engineCapacity = engineCapacity;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getManufacturingYear() {
		return manufacturingYear;
	}

	public void setManufacturingYear(int manufacturingYear) {
		this.manufacturingYear = manufacturingYear;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public int getPassengerCapacity() {
		return passengerCapacity;
	}

	public void setPassengerCapacity(int passengerCapacity) {
		this.passengerCapacity = passengerCapacity;
	}

	public double getEngineCapacity() {
		return engineCapacity;
	}

	public void setEngineCapacity(double engineCapacity) {
		this.engineCapacity = engineCapacity;
	}
    
    
}
