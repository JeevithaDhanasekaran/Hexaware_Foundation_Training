package com.carrental.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBconnection {
	private static Connection conn=null;
	
	public static Connection getConnection(){
		
		try {
			InputStream input=DBconnection.class.getClassLoader().getResourceAsStream("db.properties");
			Properties props=new Properties();
			props.load(input);
			
			String url=props.getProperty("db.url");
			String userName=props.getProperty("db.user");
			String password=props.getProperty("db.password");
			String driver=props.getProperty("db.driver");
			
			Class.forName(driver);
			
			conn=DriverManager.getConnection(url,userName,password);
			System.out.println("Database connected Successfully !");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Database Connection Failed");
		}
		
		return conn;
	}
}
