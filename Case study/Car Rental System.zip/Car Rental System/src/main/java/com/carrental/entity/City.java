package com.carrental.entity;

public class City {
	private int cityID;
    private String cityName;
    
    public City() {}
    
	public City(int cityID, String cityName) {
		super();
		this.cityID = cityID;
		this.cityName = cityName;
	}
	public int getCityID() {
		return cityID;
	}
	public void setCityID(int cityID) {
		this.cityID = cityID;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
    
    
    
}
