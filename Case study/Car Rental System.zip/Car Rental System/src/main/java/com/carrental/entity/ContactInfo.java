package com.carrental.entity;

public class ContactInfo {
	private int contactID;
    private int customerID;
    private String email;
    private String phoneNumber;
    
    public ContactInfo() {}
    
	public ContactInfo(int contactID, int customerID, String email, String phoneNumber) {
		
		this.contactID = contactID;
		this.customerID = customerID;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}
	public int getContactID() {
		return contactID;
	}
	public void setContactID(int contactID) {
		this.contactID = contactID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
    
    
}
