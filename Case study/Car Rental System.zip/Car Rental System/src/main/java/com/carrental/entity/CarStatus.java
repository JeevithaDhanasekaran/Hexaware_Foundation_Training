package com.carrental.entity;

public class CarStatus {
	private int statusID;
    private String status;
    private int vehicleID;
    
    public CarStatus() {}
    
	public CarStatus(int statusID, String status, int vehicleID) {
		super();
		this.statusID = statusID;
		this.status = status;
		this.vehicleID = vehicleID;
	}

	public int getStatusID() {
		return statusID;
	}

	public void setStatusID(int statusID) {
		this.statusID = statusID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

}
