package com.carrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.carrental.entity.Customer;
import com.carrental.entity.Lease;
import com.carrental.entity.Vehicle;
import com.carrental.util.DBconnection;

public class CarLeaseRepositoryImpl implements ICarLeaseRepository{

	private final Connection conn;
	
	public CarLeaseRepositoryImpl() {
		this.conn=DBconnection.getConnection();
	}
	
	@Override
	public void addVehicle(Vehicle vehicle) {
		// TODO Auto-generated method stub
		String query="INSERT INTO VEHICLE (make, model, manufacturingYear, dailyRate, passengerCapacity, engineCapacity) VALUES(?,?,?,?,?,?)";
		try( PreparedStatement stmt=conn.prepareStatement(query)){
			stmt.setString(1, vehicle.getMake());
            stmt.setString(2, vehicle.getModel());
            stmt.setInt(3, vehicle.getManufacturingYear());
            stmt.setDouble(4, vehicle.getDailyRate());
            stmt.setInt(5, vehicle.getPassengerCapacity());
            stmt.setDouble(6, vehicle.getEngineCapacity());
            
            stmt.executeUpdate();
            
//            System.out.println("Added successfully!");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void removeVehicle(int vehicleID) {
		// TODO Auto-generated method stub
		String query="DELETE FROM VEHICLE WHERE vehicleID=?";
		try(
				PreparedStatement stmt=conn.prepareStatement(query);
				){
			stmt.setInt(1, vehicleID);
			
            stmt.executeUpdate();
//            System.out.println("Removed Successfully !");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Vehicle> listAvailableVehicles(int cityID) {
		// TODO Auto-generated method stub
		List<Vehicle> vehicles = new ArrayList<>();
		String query="SELECT * FROM Vehicle v "
				+ " JOIN VehicleCity vc ON v.vehicleID = vc.vehicleID "
				+ "WHERE vc.cityID = ? "
				+ "AND  v.vehicleID NOT IN (SELECT vehicleID FROM Lease WHERE endDate > NOW())";
		try(PreparedStatement stmt=conn.prepareStatement(query)){
			stmt.setInt(1, cityID);
			
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				vehicles.add(new Vehicle(
		                rs.getInt("vehicleID"),
		                rs.getString("make"),
		                rs.getString("model"),
		                rs.getInt("manufacturingYear"),
		                rs.getDouble("dailyRate"),
		                rs.getInt("passengerCapacity"),
		                rs.getDouble("engineCapacity")
		            ));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return vehicles;
	}

	@Override
	public List<Vehicle> listRentedVehicles() {
		// TODO Auto-generated method stub
		List<Vehicle> vehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicle WHERE vehicleID IN (SELECT vehicleID FROM Lease WHERE endDate > NOW())";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                vehicles.add(new Vehicle(
                        rs.getInt("vehicleID"),
                        rs.getString("make"),
                        rs.getString("model"),
                        rs.getInt("manufacturingYear"),
                        rs.getDouble("dailyRate"),
                        rs.getInt("passengerCapacity"),
                        rs.getDouble("engineCapacity")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vehicles;
	}

	@Override
	public Vehicle findVehicleById(int vehicleID) {
		// TODO Auto-generated method stub
		String query = "SELECT * FROM Vehicle WHERE vehicleID = ?";
        try ( PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, vehicleID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Vehicle(
                        rs.getInt("vehicleID"),
                        rs.getString("make"),
                        rs.getString("model"),
                        rs.getInt("manufacturingYear"),
                        rs.getDouble("dailyRate"),
                        rs.getInt("passengerCapacity"),
                        rs.getDouble("engineCapacity")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
	}

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO Customer (firstName, lastName) VALUES (?, ?)";
        try (
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	@Override
	public void removeCustomer(int customerID) {
		// TODO Auto-generated method stub
		String query = "DELETE FROM Customer WHERE customerID=?";
        try (
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerID);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public List<Customer> listCustomers() {
		// TODO Auto-generated method stub
		List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";
        try (
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                	customers.add(new Customer(
                        rs.getInt("customerID"),
                        rs.getString("firstName"),
                        rs.getString("lastName")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customers;
	}

	@Override
	public Customer findCustomerById(int customerID) {
		// TODO Auto-generated method stub
		String query = "SELECT * FROM Customer WHERE customerID = ?";
        try (
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Customer(
                        rs.getInt("customerID"),
                        rs.getString("firstName"),
                        rs.getString("lastName")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
	}

	@Override
	public Lease createLease(int customerID, int vehicleID, Date startDate, Date endDate,String leaseType) {
		// TODO Auto-generated method stub
		String query="INSERT INTO Lease(vehicleID, customerID, startDate, endDate, leaseType) VALUES(?,?,?,?,?)";
		
		try(PreparedStatement stmt=conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS)){
			stmt.setInt(1, vehicleID);
			stmt.setInt(2, customerID);
			stmt.setDate(3,new java.sql.Date(startDate.getTime()));
			stmt.setDate(4, new java.sql.Date(endDate.getTime()));
			stmt.setString(4, leaseType);
			
			int rowsInserted=stmt.executeUpdate();
			
			if(rowsInserted >0) {
				ResultSet generatedKeys=stmt.getGeneratedKeys();
				if(generatedKeys.next()) {
					return new Lease(
							generatedKeys.getInt(1),
							vehicleID,
							customerID,
							startDate,
							endDate,
							leaseType
							);
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Lease returnVehicle(int leaseID) {
		// TODO Auto-generated method stub
		
		String query="UPDATE Lease SET endDate= NOW() WHERE LeaseID=?";
		
		try(PreparedStatement stmt=conn.prepareStatement(query)){
			stmt.setInt(1, leaseID);
			
			int rowsAffected=stmt.executeUpdate();
			
			if(rowsAffected >0)
				return getLeaseById(leaseID);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	
		return null;
	}

	@Override
	public List<Lease> listActiveLeases() {
		// TODO Auto-generated method stub
		List<Lease> leases = new ArrayList<>();
	    String query = "SELECT * FROM Lease WHERE endDate > NOW()";
	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {
	        while (rs.next()) {
	            leases.add(new Lease(
	                rs.getInt("leaseID"),
	                rs.getInt("vehicleID"),
	                rs.getInt("customerID"),
	                rs.getDate("startDate"),
	                rs.getDate("endDate"),
	                rs.getString("leaseType")
	            ));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return leases;
	}

	@Override
	public List<Lease> listLeaseHistory() {
		// TODO Auto-generated method stub
		List<Lease> leases = new ArrayList<>();
	    String query = "SELECT * FROM Lease WHERE endDate < NOW()";
	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {
	        while (rs.next()) {
	            leases.add(new Lease(
	                rs.getInt("leaseID"),
	                rs.getInt("vehicleID"),
	                rs.getInt("customerID"),
	                rs.getDate("startDate"),
	                rs.getDate("endDate"),
	                rs.getString("leaseType")
	            ));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return leases;
	}

	@Override
	public void recordPayment(Lease lease, double amount) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO Payment (leaseID, paymentDate, amount) VALUES (?, NOW(), ?)";
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, lease.getLeaseID());
	        stmt.setDouble(2, amount);
	        stmt.executeUpdate();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	@Override
	public Lease getLeaseById(int leaseID) {
		    String query = "SELECT * FROM Lease WHERE leaseID = ?";
		    try (PreparedStatement stmt = conn.prepareStatement(query)) {
		        stmt.setInt(1, leaseID);
		        ResultSet rs = stmt.executeQuery();
		        if (rs.next()) {
		            return new Lease(
		                rs.getInt("leaseID"),
		                rs.getInt("vehicleID"),
		                rs.getInt("customerID"),
		                rs.getDate("startDate"),
		                rs.getDate("endDate"),
		                rs.getString("leaseType")
		            );
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		    return null;
	}
//	close the connection check mandatoy??

}
