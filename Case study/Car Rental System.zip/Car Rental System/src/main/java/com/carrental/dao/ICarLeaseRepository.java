package com.carrental.dao;

import java.util.Date;
import java.util.List;

import com.carrental.entity.Customer;
import com.carrental.entity.Lease;
import com.carrental.entity.Vehicle;

public interface ICarLeaseRepository {
	void addVehicle(Vehicle vehicle);
    void removeVehicle(int vehicleID);
    List<Vehicle> listAvailableVehicles(int cityID);
    List<Vehicle> listRentedVehicles();
    Vehicle findVehicleById(int vehicleID);
    
    void addCustomer(Customer customer);
    void removeCustomer(int customerID);
    List<Customer> listCustomers();
    Customer findCustomerById(int customerID);
    
    Lease createLease(int customerID, int vehicleID, Date startDate, Date endDate,String leaseType);
    Lease returnVehicle(int leaseID);
    Lease getLeaseById(int leaseID);
    List<Lease> listActiveLeases();
    List<Lease> listLeaseHistory();
    
    void recordPayment(Lease lease, double amount);    
    
}
